let img; // 定义一个全局变量来存储图像
// 设置函数，用于初始化画布和图像
function setup() {
    createCanvas(windowWidth, windowHeight); // 创建一个与窗口大小相同的画布
    img = loadImage("R.jpg", function() { // 加载图像并存储在img变量中
        img.resize(width, height); // 将图像大小调整为画布大小
    });
    background(0); // 将背景设置为黑色
    noStroke(); // 不绘制边框
    randomSeed(1000);
}

// 绘制函数，用于在画布上绘制图像
function draw() {
    let seed = millis() * 0.001; // 使用时间作为随机值
    randomSeed(seed); // 使用随机种子
    for (let i = 0; i < 1000; i++) { // 每秒生成1000个动画粒子
        let x = int(random(width)); // 在画布宽度范围内随机选择一个x坐标
        let y = int(random(height)); // 在画布高度范围内随机选择一个y坐标
        let col = img.get(x, y); // 获取该坐标点的颜色
        
        // 计算矩形的长度和角度
        let length = map(saturation(col), 0, 255, 1, 40); // 将颜色的饱和度映射为长度
        let angle = map(hue(col), 0, 255, 0, 360); // 将颜色的色调映射为角度
        
        // 加入噪音
        let n = noise(x * 0.01, y * 0.01); // 计算噪音值
        console.log(n)
        length *= n; // 用噪音值调整长度
        angle += n * 360; // 用噪音值调整角度
        
        // 设置填充颜色
        fill(red(col), green(col), blue(col), 127); // 设置填充颜色
        
        // 保存当前的绘图样式和变换
        push();
        // 移动到随机选择的位置
        translate(x, y); 
        // 旋转矩形
        rotate(radians(angle));
        // 绘制一个矩形
        rect(0, 0, length, 1);
        // 恢复之前保存的绘图样式和变换
        pop();
    }
}
